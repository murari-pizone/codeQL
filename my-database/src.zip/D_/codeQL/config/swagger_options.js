// // swaggerOptions.js
const swaggerJSDoc = require('swagger-jsdoc');

const swaggerOptions = {
  swaggerDefinition: {
    openapi: '3.0.0',
    info: {
      title: 'A2B Swagger',
      version: '1.0.0',
      description: 'API documentation',
    },
    // servers: [{ url: 'https://dev-middleware.aabsweets.com:8081' }],
    servers: [{ url: 'http://localhost:3000' }],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT', // Optional
        },
      },
    },
    security: [{ bearerAuth: [] }], // Apply it globally

    parameters: {
      ContentType: {
        name: 'Content-Type',
        in: 'header',
        required: true,
        schema: {
          type: 'string',
          default: 'application/json',
        },
      },
    },
  },
  apis: [
    './server.js',
    './routes/routes.js',
    './aggregator_module/routes.js',
    './user_module/routes.js',
    './item_module/routes.js',
    './store_timing_module/routes.js',
    './outlets_module/routes.js',
    './menu_module/routes.js',
    './orders_module/routes.js',
    './branches_module/routes/storeBranchRoutes.js',
  ], // Adjust the path according to your folder structure
};

const swaggerDocs = swaggerJSDoc(swaggerOptions);

module.exports = swaggerDocs;
